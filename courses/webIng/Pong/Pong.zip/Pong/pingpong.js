/**
 * @author Lisha
 */
var dirx = 1;
var diry = 1;
var spdx = 10;
var spdy = setRand();
var imgLeftInt;
var imgTopInt;
var imgHeight;
var imgWidth;
var winWidth;
var winHeight;
var theBall;

// timer control var
var t=0;
// paddle location vars
var rInt, lInt;


function startGame() {
 
 if(t==0){
 t = setInterval('animBall()', 80);
 }
}

function animBall() {
 theBall = document.images['ball1']; 
 imgLeftInt = parseInt(theBall.style.left);
 imgTopInt = parseInt(theBall.style.top);
 imgHeight =  parseInt(theBall.height);
 imgWidth =  parseInt(theBall.width);
 winWidth = 735;
 winHeight = 390;

 PadlLoc();
 padRight=parseInt(rpadl.style.left);
 padLeft=parseInt(lpadl.style.left)+parseInt(lpadl.style.width);
 if ((imgLeftInt+imgWidth)== padRight){
 rPadlHit();
 } else     if ((imgLeftInt)== padLeft){
 lPadlHit();
 }
 
 if(dirx == 1){                               // if I should go right...
 goRight();
 } else {                                     // otherwise, I'd better go left!
 goLeft();
 }

 if(diry == 1) {                             // if I should go down...
 goDown();
 } else {                                    // otherwise, I'll go up!
 goUp();
    }

}

function rPadlHit(){
     rBottom = rInt+parseInt(rpadl.style.height);
     rTop = rInt-imgHeight;
     if ((imgTopInt < rBottom ) && (imgTopInt > rTop)){
    dirx=0;
     }   
}

function lPadlHit(){
    lBottom = lInt+parseInt(lpadl.style.height);
    lTop = lInt-imgHeight;
    if ((imgTopInt < lBottom ) && (imgTopInt > lTop)){
        dirx=1;
    }
}

function PadlLoc() {
    rpadl = document.getElementById('rightpaddle');
    rInt = parseInt(rpadl.style.top);
    lpadl = document.getElementById('leftpaddle');
    lInt = parseInt(lpadl.style.top);
    return rpadl,rInt, lpadl, lInt;
}

function goRight() {
     theBall.style.left = imgLeftInt+spdx +"px";
     if (imgLeftInt >  (winWidth-(imgWidth))){
    score('left');
     }
}

function goLeft() {
     theBall.style.left = (imgLeftInt-spdx) +"px";
     if (imgLeftInt <  10){
    score('right');
     }
}

function goDown() {
    theBall.style.top = imgTopInt+spdy+"px";
    if (imgTopInt >  (winHeight-(imgHeight+spdy))){
        diry = 0;
        spdy= setRand();
    }
}

function goUp() {
    theBall.style.top = (imgTopInt-spdy) +"px";
    if (imgTopInt < 5){
        diry = 1;
        spdy= setRand();
    }
}

function setRand() {
        randnum= Math.floor(Math.random()*6)+2;
        return randnum;
}

function rPadMove(dir) {
    if(dir==1 && rInt>5){
           rpadl.style.top = (rInt-12)+"px";       
    } else if (dir==0 && rInt < 320){
         rpadl.style.top = (rInt+12)+"px";
    }
}

 function lPadMove(dir) {
    if(dir==1 && lInt > 5){
        lpadl.style.top = (lInt-12)+"px";
    } else if(dir==0 && lInt < 320){
        lpadl.style.top = (lInt+12)+"px";
    }
 }

// variables to determine what a key press means
var rup = '9';  // right paddle up
var rdn = '0';  // right paddle down
var lup = '1';  // left paddle up
var ldn = '2';  // left paddle down
function CaptureKey(e) {
   if (e.keyCode) {
        keycode=e.keyCode;
   }
     else {
         keycode=e.which;   
     }
   move=String.fromCharCode(keycode);
  
      if (move == "s") {
          startGame();       
      }
      if (move == rup) {
        rPadMove(1);
     }
      if (move == rdn) {
        rPadMove(0);
     }
      if (move == lup) {
          lPadMove(1);
     }
      if (move == ldn) {
        lPadMove(0);
     }
}

function score(side) {
	clearInterval(t);
    msgBox = document.getElementById('messageBox');
    msgBox.style.visibility = "visible";

    scorePop = "<p>Point for the "+side+" side!<br /> ";
    scorePop += "To serve the ball again, press \"s\" after closing this pop-up.</p>";
    scorePop += "<a href=\"javascript:return false\" onClick=\prepNewGame('"+side+"');return false;\">X Close</a>";
     
     msgBox.innerHTML = scorePop;


}

function prepNewGame(side){
	t=0;
    msgBox.style.visibility='hidden';
    theBall.style.top = "10px";

    if(side == "left"){
    theBall.style.left = "25px";
    rpadl.style.top = "5px";
    lpadl.style.top = "5px";
    } else {
    theBall.style.left = (winWidth-40) + "px";
    rpadl.style.top = "5px";
    lpadl.style.top = "5px";
    }
   
}